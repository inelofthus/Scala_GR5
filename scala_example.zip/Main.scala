import akka.actor._

case class DataStructure(WithValue: Double)

class Unit1 extends Actor {
	def receive = {
		// Pattern matching on types
		case t: Integer => println(s"Pattern matching an integer: $t")

		// Pattern matching on strings, and sending something back to sender
		case "SYN" => sender ! "ACK"

		// Matching a case class
		case DataStructure(value) => println(s"got $value")

		// Matching anything
		case _ => {
			println("Unit1: Sorry, I don't know what sender meant :(")
			println("Multiple statements with {} braces")
		}
	}
}

class Unit2 extends Actor {
	override def receive = {
		case "ACK" => println("Connection established with Unit 1")

		// Sending from/to actors
		case t: ActorRef => t ! "SYN"

		case _ => println("Unit2: Sorry, I don't know what sender meant :(")
	}
}

object Main extends App {
	val system = ActorSystem("main")
	val unit1 = system.actorOf(Props[Unit1], name = "unit-1")
	val unit2 = system.actorOf(Props[Unit2], name = "unit-2")
	unit1 ! 312
	unit1 ! DataStructure(3.14159)
	unit2 ! unit1
	unit1 ! "hello"
}

