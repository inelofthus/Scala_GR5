# How to use this example #
To run this example install scala and sbt and run (in a terminal) `sbt run` in this directory.

# Errors #
If you get the error `sbt.ResolveException: unresolved dependecy: com.typesafe.akka...`
then you need to modify your `build.sbt` script to use the scala version you have. Replace `akka-actor_2.10` with
`akka-actor_<YOUR SCALA VERSION>`. <YOUR SCALA VERSION> is found by running `scala -version`.
